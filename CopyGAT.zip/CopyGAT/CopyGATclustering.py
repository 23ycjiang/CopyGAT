import numpy as np
from sklearn.cluster import KMeans, DBSCAN
from sklearn.mixture import GaussianMixture
import leidenalg
import igraph as ig
import numpy as np
from sklearn.neighbors import NearestNeighbors

import leidenalg
import igraph as ig
import numpy as np
from sklearn.neighbors import NearestNeighbors

def find_clones_gmm(latent_data, n_clones=2):
 

    gmm = GaussianMixture(n_components=n_clones, n_init=5, max_iter=100000)
    gmm.fit(latent_data)
    pred_label = gmm.predict(latent_data)

    return pred_label


def auto_corr(cluster_data):

    n_samples = cluster_data.shape[0]
    res = 0
    count = 0

    for i in range(n_samples):
        for j in range(i, n_samples):
            res += np.sum(cluster_data[i,:] * cluster_data[j,:])
            count += 1
    res = res / count
    autocorrelation = res / np.var(cluster_data,axis=1).mean()

    return autocorrelation


def find_normal_cluster(x_bin, pred_label, n_clusters=2):
 

    cluster_auto_corr = np.zeros([n_clusters])

    for i in range(n_clusters):
        cluster_mean = x_bin[pred_label == i, :].mean(axis=0)
        cluster_x = x_bin[pred_label == i, :]

        cluster_auto_corr[i] = auto_corr(cluster_x - cluster_mean)

    normal_index = np.argmax(cluster_auto_corr)

    return cluster_auto_corr, normal_index