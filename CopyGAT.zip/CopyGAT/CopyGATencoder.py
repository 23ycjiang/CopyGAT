
import tensorflow as tf
import tensorflow.keras as keras
from tensorflow.keras.layers import Dense, Activation
from CopyGAT.CopyGATlayers import FullyConnLayer, GaussianSampling

import tensorflow as tf
from tensorflow.keras import layers
from spektral.layers import GCNConv, GATConv

class Encoder(tf.keras.Model):
    
    def __init__(self, latent_dim=10, hidden_dim=128, n_layers=2, use_gat=True, **kwargs):

        super(Encoder, self).__init__(**kwargs)
        self.eps = 1e-4
        self.n_layers = n_layers
        self.use_gat = use_gat

        self.graph_layers = []
        for _ in range(n_layers):
            if use_gat:
                self.graph_layers.append(GATConv(hidden_dim, activation="relu"))
            else:
                self.graph_layers.append(GCNConv(hidden_dim, activation="relu"))

        self.dense_mean = layers.Dense(latent_dim)
        self.dense_var = layers.Dense(latent_dim)
        self.sampling = GaussianSampling()
    def call(self, inputs):
        X, A = inputs
        for layer in self.graph_layers:
            X = layer([X, A]) 
        
        z_mean = self.dense_mean(X)
        z_log_var = self.dense_var(X)
        z_var = tf.math.exp(z_log_var) + self.eps

        z = self.sampling((z_mean, z_var))
        
        return z_mean, z_var, z

    def reparameterize(self, mean, var):

        epsilon = tf.keras.backend.random_normal(shape=tf.shape(mean))
        return mean + tf.sqrt(var) * epsilon


class CNEncoder(keras.models.Model):

    def __init__(self,
                 original_dim,
                 max_cp,
                 name="cnencoder", **kwargs):
        super(CNEncoder, self).__init__(name=name, **kwargs)
        self.max_cp = max_cp
        self.mu_nn = keras.Sequential([
                                        Dense(original_dim),
                                        Activation(keras.activations.sigmoid)
                                        ])

    def call(self, inputs):
        copy = self.mu_nn(inputs[1]) * self.max_cp
        copy_sum = tf.reduce_sum(copy, 1, keepdims=True)
        pseudo_sum = tf.reduce_sum(inputs[0], 1, keepdims=True)
        norm_copy = copy / copy_sum * pseudo_sum

        return norm_copy



