#! /usr/bin/env python3

import numpy as np
import pandas as pd
import scanpy as sc
import os
import pybiomart

CHR_BASE_PAIRS = np.array([
    248956422,
    242193529,
    198295559,
    190214555,
    181538259,
    170805979,
    159345973,
    145138636,
    138394717,
    133797422,
    135086622,
    133275309,
    114364328,
    107043718,
    101991189,
    90338345,
    83257441,
    80373285,
    58617616,
    64444167,
    46709983,
    50818468,
    156040895])


def _build_gene_map(chr_pos=CHR_BASE_PAIRS):
    server = pybiomart.Server(host='http://www.ensembl.org')
    mart = server['ENSEMBL_MART_ENSEMBL']
    dataset = mart['hsapiens_gene_ensembl']
    attributes = [#'ensembl_transcript_id',
                  'external_gene_name', 
                  'ensembl_gene_id',
                  'chromosome_name',
                  'start_position',
                  'end_position']
    
    gene_info = dataset.query(attributes= attributes)
    gene_info.rename(columns={'Chromosome/scaffold name': 'chr'}, inplace=True)

    gene_info.loc[gene_info.chr == 'X', 'chr'] = '23'

    gene_info = gene_info[
        gene_info['chr'].isin(
            np.arange(1, 24).astype(str)
        )
    ]

    gene_info = gene_info.copy()
    gene_info.loc[:, 'chr'] = gene_info.chr.astype(int)
    gene_info = gene_info.sort_values(by=['chr', 'Gene start (bp)'])


    gene_map = gene_info
    gene_map['abspos'] = gene_map['Gene start (bp)']
    for i in range(len(chr_pos)):
        gene_map.loc[gene_map['chr'] == i + 1, 'abspos'] += chr_pos[:i].sum()

    return gene_map


def build_gene_map(server_url, attributes, chr_pos=CHR_BASE_PAIRS):
    server = pybiomart.Server(host=server_url)
    mart = server['ENSEMBL_MART_ENSEMBL']
    dataset = mart['hsapiens_gene_ensembl']
    gene_info = dataset.query(attributes=attributes)
    gene_info.rename(columns={'Chromosome/scaffold name': 'chr'}, inplace=True)
    gene_info.loc[gene_info.chr == 'X', 'chr'] = '23'
    valid_chromosomes = np.arange(1, 24).astype(str)
    gene_info = gene_info[gene_info['chr'].isin(valid_chromosomes)]
    gene_info['chr'] = gene_info['chr'].astype(int)
    gene_info = gene_info.sort_values(by=['chr', 'Gene start (bp)'])
    gene_info['abspos'] = gene_info['Gene start (bp)']
    for i in range(len(chr_pos)):
        gene_info.loc[gene_info['chr'] == i + 1, 'abspos'] += chr_pos[:i].sum() 
    return gene_info
    
def bin_genes_from_anndata(adata, bin_size, gene_map):
    output_dir = ""

    initial_genes = adata.var.copy()

    sc.pp.filter_genes(adata, min_cells=1)

    filtered_genes_low_expression = initial_genes.loc[~initial_genes.index.isin(adata.var.index)]

    map_chr = dict(gene_map[['Gene name', 'chr']].values)
    adata.var['chr'] = adata.var.gene_ids.map(map_chr)
    map_abs = dict(gene_map[['Gene name', 'abspos']].values)
    adata.var['abspos'] = adata.var.gene_ids.map(map_abs)

    missing_info_genes = adata.var[adata.var.chr.isna() | adata.var.abspos.isna()]


    adata_clean = adata[:, adata.var.chr.notna() & adata.var.abspos.notna()].copy()
    adata_clean.var['chr'] = adata_clean.var['chr'].astype('int')
    adata_clean.var['abspos'] = adata_clean.var['abspos'].astype('int')

    adata_clean = adata_clean[:, list(adata_clean.var.sort_values(by='abspos').index)].copy()

    n_exceeded = adata_clean.var['chr'].value_counts() % bin_size
    ind_list = []

    for chrom in n_exceeded.index:
        n = n_exceeded[chrom]
        ind = adata_clean.var[adata_clean.var['chr'] == chrom].sort_values(
            by=['n_cells', 'abspos'])[:n].index.values
        ind_list.append(ind)

    exceeded_genes = adata_clean.var.loc[np.concatenate(ind_list)]

    data = adata_clean[:, ~adata_clean.var.index.isin(np.concatenate(ind_list))].copy()

    abspos_values = data.var['abspos'].values.astype(int)

    gene_ids = data.var['gene_ids'].values
    abspos_values = data.var['abspos'].values.astype(int)

    abspos_with_ids = np.column_stack((gene_ids, abspos_values))

    bin_number = adata_clean.var['chr'].value_counts() // bin_size
    chrom_bound = bin_number.sort_index().cumsum()
    chrom_list = [(0, chrom_bound[1])]

    for i in range(2, 24):
        start_p = chrom_bound[i - 1]
        end_p = chrom_bound[i]
        chrom_list.append((start_p, end_p))
    return data, chrom_list

